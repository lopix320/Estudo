import React from "react"
import './App.css'

let [op, numero, texto, ctrl, valor1, valor2, total] = ["", "", "", 0, 0, 0, 0]

export const Button = () =>{
  const [elemento, setElemento] = React.useState(0)
  return (
    <>
      <button onClick={EventLoop} className="botoes" value="pot">pot </button>
      <button onClick={EventLoop} className="botoes" value="arr">arr </button>
      <button onClick={EventLoop} className="botoes" value="raiz">raiz </button>
      <button onClick={EventLoop} className="botoes">max </button>
      <button onClick={EventLoop} className="botoes" value="mrc">mrc </button>
      <button onClick={EventLoop} className="botoes" value="m-">m- </button>
      <button onClick={EventLoop} className="botoes" value="m+">m+ </button>
      <button onClick={EventLoop} className="botoes" id="vermelho" value="X">x </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="7">7 </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="8">8 </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="9">9 </button>
      <button onClick={EventLoop} className="botoes" id="vermelho" value="+">+ </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="4">4 </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="5">5 </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="6">6 </button>
      <button onClick={EventLoop} className="botoes" id="vermelho" value="-">- </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="1">1 </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="2">2 </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="3">3 </button>
      <button onClick={EventLoop} className="botoes" id="vermelho" value="/">/ </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="0">0 </button>
      <button onClick={EventLoop} className="botoes" id="preto" value=".">. </button>
      <button onClick={EventLoop} className="botoes" id="preto" value="C">C </button>
      <button onClick={EventLoop} className="botoes" id="amarelo" value="=">= </button>
    </>
  )
}

export const EventLoop = (event) =>{
  let v1 = event.target.value
  if(v1 == "pot" || v1 == "arr" || v1 == "raiz" || v1 == "m-" || 
  v1 == "m+" || v1 == "+" || v1 == "-" || v1 == "/" || v1 == "X"){
    op = v1
    texto = texto.concat(" " + v1 + " ")
    if(ctrl == 0){
      valor1 = numero
      numero = ""
      ctrl = 1
    }
    console.log(texto)
    console.log("entro")
    // return (
      document.querySelector('.box2').innerHTML = texto
      // )
    }
    else{
      texto = texto.concat(v1)
      numero = numero.concat(v1)
      console.log(texto)
      if(ctrl == 1){
        valor2 = numero
      }
      // return (
      document.querySelector('.box2').innerHTML = texto
    // )
  }

  if(v1 == "="){
    soma(op)
    sub(op)
    multi(op)
    divisao(op)
    pot(op)
    raiz(op)
    arr(op)
    console.log(valor1 + " + " + valor2 + " = " + total)
  }
}

function soma(operador) {
  if(operador == "+"){
    total = parseFloat(valor1) + parseFloat(valor2);
    return total
  }
}
function sub(operador) {
  if(operador == "-"){
    total = parseFloat(valor1) - parseFloat(valor2);
    return total
  }
}
function multi(operador) {
  if(operador == "X"){
    total = parseFloat(valor1) * parseFloat(valor2);
    return total
  }
}
function divisao(operador) {
  if(operador == "/"){
    total = parseFloat(valor1) / parseFloat(valor2);
    return total
  }
}
function pot(operador) {
  if(operador == "pot"){
    total = Math.pow(parseFloat(valor1), parseFloat(valor2));
    return total
  }
}
function raiz(operador) {
  if(operador == "raiz"){
    total = Math.sqrt(valor1).toFixed(1)
    return total
  }
}
function arr(operador) {
  if(operador == "arr"){
    total = Math.round(valor1)
    return total
  }
}
