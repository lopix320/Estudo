import React from 'react'

export const Button = () => {
  return (
    <>
        <button>pot </button>
    </>
  )
}

export default Button
