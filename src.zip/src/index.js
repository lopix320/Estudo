import React from 'react';
import ReactDOM from 'react-dom/client';
import './App.css'
import {Button, EventLoop} from './App'

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    <div className='box1'>
      <div className='box2'>
      </div>
      <div className='box3'>
        <Button></Button>
      </div>

    </div>
  </>
)