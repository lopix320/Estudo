import React from "react"

const luana = {
    cliente: "Luana",
    idade: 27,
    compras: [
        { nome: 'Notebook', preco: 'R$ 2500'},
        { nome: 'Geladeira', preco: 'R$ 3000'},
        { nome: 'Smartphone', preco: 'R$ 1500'},
    ],
    ativa: false,
}

const roberto = {
    cliente: "Roberto",
    idade: 32,
    compras: [
        { nome: 'Notebook', preco: 'R$ 2500'},
        { nome: 'Geladeira', preco: 'R$ 7000'},
        { nome: 'Smartphone', preco: 'R$ 1500'},
    ],
    ativa: true,
}

const App = () => {
    const dados = roberto
    const total =  dados.compras.map(item => 
    Number(item.preco.slice(2))
    ).reduce((a, b) => a + b)
    const gasto = total >= 10000 ? "Ta gastando muito" : ""
    return (
        <>
            <div>
                <p>Nome: {dados.cliente}</p> 
                <p>Idade: {dados.idade}</p> 
                <p>
                   Idade: <span style={dados.ativa ? {color: "green"} : {color: "red"}}>{dados.ativa ? 'Ativa' : 'Inativa'}</span> 
                </p> 
                <p>Total gasto: R$:{total}</p>
                {total >= 10000 && <p>Ta gastando muito</p>}
            </div>
        </>
    )
}

export default App